"""Four-legged scout robot with swept collision checks and simulated energy use."""
from __future__ import annotations
import math, random
import pygame
from config import SETTINGS, COLORS


class ScoutRobot:
    def __init__(self, start, color=None, name="Cave Scout"):
        self.x=float(start[0]); self.y=float(start[1]); self.vx=self.vy=0.0
        self.heading=math.pi/2; self.color=color or COLORS["robot"]; self.name=name
        self.battery=SETTINGS.battery_capacity; self.walk_phase=0.0; self.trail=[(self.x,self.y)]
        self.last_position=(self.x,self.y); self.uncertainty=0.8; self.lidar=[]
        self.scanning=0.0; self.life_scanning=0.0; self.sleeping=False; self.light=True
        self.minerals_found=0; self.life_confirmed=0; self.scan_count=0; self.distance=0.0
        self.blocked_steps=0

    @property
    def cell(self): return (int(round(self.x)),int(round(self.y)))

    def update(self, target, cave, dt, speed=1.0, safe=False):
        """Move with acceleration limits and swept footprint collision checking."""
        old=(self.x,self.y)
        if safe or self.sleeping:
            self.vx*=max(0.0,1.0-4.0*dt); self.vy*=max(0.0,1.0-4.0*dt)
            self.battery=max(0,self.battery-0.002*dt)
            self.last_position=old
            return
        if target:
            dx,dy=target[0]-self.x,target[1]-self.y
            d=math.hypot(dx,dy)
            if d>0.08:
                desired=(dx/d*speed,dy/d*speed)
                accel=2.0*dt
                self.vx+=max(-accel,min(accel,desired[0]-self.vx))
                self.vy+=max(-accel,min(accel,desired[1]-self.vy))
                mag=math.hypot(self.vx,self.vy)
                if mag>speed and mag>0:
                    self.vx*=speed/mag; self.vy*=speed/mag
                if mag>0.03:self.heading=math.atan2(self.vy,self.vx)
            else:
                damping=max(0.0,1.0-5.0*dt); self.vx*=damping; self.vy*=damping
        else:
            damping=max(0.0,1.0-5.0*dt); self.vx*=damping; self.vy*=damping

        # Substep the motion to prevent tunnelling through thin walls at high sim speed.
        dx,dy=self.vx*dt,self.vy*dt
        distance=math.hypot(dx,dy)
        steps=max(1,int(math.ceil(distance/0.12)))
        moved=0.0
        for i in range(steps):
            nx=self.x+dx/steps; ny=self.y+dy/steps
            if cave.can_occupy(nx,ny,0.28):
                self.x,self.y=nx,ny
                moved += math.hypot(dx/steps,dy/steps)
            else:
                self.vx*=0.0; self.vy*=0.0; self.blocked_steps+=1
                break
        terrain=int(cave.terrain[self.cell[1],self.cell[0]]) if cave.is_walkable(*self.cell) else 0
        factor={1:1.0,2:.72,3:.48}.get(terrain,1.0)
        self.distance+=moved
        self.walk_phase+=moved*11.0
        self.battery=max(0,self.battery-SETTINGS.move_drain*moved/factor)
        if self.light:self.battery=max(0,self.battery-SETTINGS.headlight_drain*dt)
        self.uncertainty=max(.45,self.uncertainty+random.uniform(-.006,.015)*dt)
        if moved>.004:
            self.trail.append((self.x,self.y))
            if len(self.trail)>900:self.trail.pop(0)
        self.last_position=old

    def draw(self, surface, to_screen, scale, alpha=255):
        sx,sy=to_screen(self.x,self.y); s=max(2,int(scale)); shadow=pygame.Surface((s*5,s*4),pygame.SRCALPHA)
        pygame.draw.ellipse(shadow,(0,0,0,100),(s*.6,s*1.3,s*3.5,s*1.5)); surface.blit(shadow,(sx-s*2,sy-s))
        c=self.color; phase=self.walk_phase
        for i,(lx,ly) in enumerate(((-.75,-.48),(.75,-.48),(-.75,.48),(.75,.48))):
            swing=math.sin(phase+(0 if i in (0,3) else math.pi))*.18
            hip=(sx+int(lx*s*.8),sy+int(ly*s*.55))
            knee=(hip[0]+int((lx*.35+swing)*s),hip[1]+int((ly*.45+math.cos(phase+i)*.06)*s))
            foot=(knee[0]+int((lx*.35+swing)*s),knee[1]+int(.22*s))
            pygame.draw.line(surface,(49,57,68),hip,knee,max(2,s//5)); pygame.draw.line(surface,c,knee,foot,max(2,s//6))
            pygame.draw.circle(surface,(190,201,213),hip,max(2,s//7)); pygame.draw.circle(surface,c,foot,max(2,s//6))
        pygame.draw.ellipse(surface,(37,48,60),(sx-s,sy-int(.5*s),2*s,int(1.15*s)))
        pygame.draw.ellipse(surface,c,(sx-int(.9*s),sy-int(.75*s),int(1.8*s),int(1.25*s)))
        pygame.draw.ellipse(surface,(58,76,91),(sx-int(.42*s),sy-int(.95*s),int(.84*s),int(.7*s)))
        hx=sx+int(math.cos(self.heading)*s*.72); hy=sy+int(math.sin(self.heading)*s*.72)
        pygame.draw.circle(surface,COLORS["cyan"],(hx,hy),max(2,s//5))
