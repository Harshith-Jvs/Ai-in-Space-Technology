"""Robust mission state machine and adaptive navigation controller."""
from __future__ import annotations
import math, time
from collections import defaultdict
import numpy as np
from algorithms import plan_grid, DStarLite, select_frontier, WallFollower, steer, Recovery
from config import SETTINGS


class MissionController:
    def __init__(self, cave, robot, belief):
        self.cave, self.robot, self.belief = cave, robot, belief
        self.phase = "Deploy"
        self.exploration, self.planner, self.local = "Utility frontier", "A*", "Safe waypoint tracking"
        self.auto, self.forced = True, None
        self.target = None; self.target_kind = "frontier"; self.path = []; self.path_index = 0; self.expanded = []
        self.events, self.switches = [], []; self.usage = defaultdict(float)
        self.phase_time = self.switch_clock = self.mission_time = self.plan_clock = 0.0
        self.wall, self.dstar = WallFollower(), DStarLite()
        self.recovery = Recovery(SETTINGS.stuck_seconds); self.recovery_target = None
        self.recovery_path = []; self.recovery_index = 0; self.recovery_distance = 0.0
        self.unreachable_frontiers = set(); self.no_route_count = 0
        self.collision_blocked = set(); self.last_collision_event_time = -999.0
        self.found = []; self.completed = self.failed = False
        self.previous_map_changes = 0; self.last_seen_count = 0; self.visited_frontiers = set()
        self.last_plan_goal = None; self.last_plan_start = None; self.last_plan_change_count = -1; self.last_planner_used = None
        self.blocked_steps_seen = getattr(robot, "blocked_steps", 0)
        self.last_reason = "Initial safe exploration"
        self._event("Mission initialized · awaiting deployment")

    def _event(self, msg):
        stamp = time.strftime("%H:%M:%S")
        self.events.append(f"{stamp}  {msg}")
        self.events = self.events[-100:]

    def _switch(self, explore=None, planner=None, local=None, reason="context changed"):
        old = (self.exploration, self.planner, self.local)
        if explore: self.exploration = explore
        if planner: self.planner = planner
        if local: self.local = local
        new = (self.exploration, self.planner, self.local)
        if old != new:
            self.last_reason = reason
            msg = f"{old[0]} / {old[1]} → {new[0]} / {new[1]}: {reason}"
            self.switches.append((self.mission_time, msg)); self._event(msg)

    def force_algorithm(self, name):
        self.auto = False; self.forced = name; self.last_reason = f"Manual override (key {name})"
        choices = {"1": ("Nearest frontier", "A*"), "2": ("Utility frontier", "A*"),
                   "3": ("Wall-follow", "A*"), "4": (None, "Dijkstra"),
                   "5": (None, "D* Lite"), "6": (None, "Theta*"), "7": (None, "A*")}
        e, p = choices[name]; self._switch(e, p, reason="manual override")

    def set_auto(self):
        self.auto = True; self.forced = None
        self.last_reason = "Automatic context-based selection"
        self._event("Automatic algorithm selection enabled")

    def _coverage(self):
        # Robot-side sensor metric: fraction of every grid cell that has received an
        # observation. This deliberately does not use the simulator's hidden cave mask.
        return self.belief.coverage()

    def _cave_coverage(self):
        # Evaluation-only metric: observed traversable cave-floor cells / actual cave
        # floor cells. Never use this ground-truth denominator for robot decisions.
        return self.belief.coverage(self.cave.walkable_mask)

    def _observed_grid_fraction(self):
        return self._coverage()

    def update(self, dt):
        dt = max(0.0, min(float(dt), 0.25))
        self.mission_time += dt; self.phase_time += dt; self.switch_clock += dt; self.plan_clock += dt
        if self.phase not in ("Mission Complete", "Mission Failed"):
            self.usage[self.planner] += dt; self.usage[self.exploration] += dt

        if self.phase == "Deploy":
            self.robot.update(None, self.cave, dt)
            if self.phase_time >= 1.2:
                self.phase = "Explore"; self.phase_time = 0.0
                self.belief.mark_free(*self.robot.cell)
                self._event("Deployment complete · LiDAR mapping started")
            return
        if self.completed or self.failed: return
        if self.robot.battery <= 0.0:
            self.failed = True; self.phase = "Mission Failed"
            self._event("Battery depleted before reaching the skylight"); return

        # Reaching the entrance is the only successful end condition.
        if self.phase == "Return" and self._distance(self.cave.entrance) < 0.85:
            self.completed = True; self.phase = "Mission Complete"
            self._event("Surface reached · map and science data ready for downlink"); return

        # Start the return early enough to avoid dying in a distant branch.
        if self.phase not in ("Return", "Mission Complete") and self.robot.battery <= SETTINGS.low_battery:
            self.phase = "Return"; self.target = self.cave.entrance; self.target_kind = "home"; self.path = []
            self._event("Battery reserve reached · return-home mode engaged")

        if self.auto and self.switch_clock >= SETTINGS.switch_interval:
            self.switch_clock = 0.0; self._choose_algorithms()

        seen_count = int(self.belief.seen.sum())
        if seen_count > self.last_seen_count + 8:
            # Newly exposed space can reveal new frontiers; allow those to be revisited.
            self.visited_frontiers.clear(); self.unreachable_frontiers.clear(); self.last_seen_count = seen_count

        if self.phase == "Explore":
            # In this simulator the cave-floor mask provides a ground-truth evaluation
            # metric. Use it only as a mission stop criterion; frontier planning and
            # path selection still use the robot's sensed occupancy map.
            if self._cave_coverage() >= SETTINGS.coverage_goal:
                self.phase = "Return"; self.target = self.cave.entrance
                self.target_kind = "home"; self.path = []; self.last_plan_goal = None
                self._event("Cave-floor mapping target reached · returning to skylight")
            else:
                self._advance_exploration_target()
        elif self.phase == "Investigate":
            self._investigate(dt)
        if self.phase == "Return":
            self.target = self.cave.entrance; self.target_kind = "home"

        # Recovery is a real multi-frame maneuver, not a one-frame velocity impulse.
        if self.recovery.active:
            self._run_recovery(dt)
            return

        self._plan_if_needed()
        waypoint = self._next_waypoint()
        if waypoint is None:
            self.robot.update(None, self.cave, dt)
            return

        speed = 0.42 if self._is_narrow() else (0.60 if self.phase == "Return" else 0.72)
        nearby = self._nearby_walls()
        before_blocked = getattr(self.robot, "blocked_steps", 0)
        narrow = self._is_narrow()
        if narrow:
            # In a squeeze, brake and turn before moving through sharp bends.
            dx, dy = waypoint[0]-self.robot.x, waypoint[1]-self.robot.y
            desired_heading = math.atan2(dy, dx)
            angle_error = (desired_heading-self.robot.heading+math.pi)%(2*math.pi)-math.pi
            if abs(angle_error) > 0.62:
                self.robot.vx *= 0.35; self.robot.vy *= 0.35
                turn = max(-2.4*dt, min(2.4*dt, angle_error))
                self.robot.heading += turn
                self.robot.update(None, self.cave, dt, speed=0.0)
            else:
                self.robot.update(waypoint, self.cave, dt, speed=min(speed, 0.30))
        else:
            # The planner's waypoint is the authoritative safe corridor. Potential-field
            # repulsion can oscillate in tight turns, so keep normal motion on the path
            # and reserve vector steering for recovery manoeuvres.
            self.robot.update(waypoint, self.cave, dt, speed=speed)
        collision_now = getattr(self.robot, "blocked_steps", 0) > before_blocked
        if collision_now:
            self._handle_collision(waypoint)
            # Collision response and route replanning happen immediately. The short
            # no-progress timer is reserved for cases where the robot stalls without contact.

        moved = math.hypot(self.robot.x-self.robot.last_position[0], self.robot.y-self.robot.last_position[1]) > 0.003
        actively_moving = self.target is not None and self._distance(self.target) > 0.65
        if self.recovery.update(moved or not actively_moving, dt):
            # Do not spend minutes executing a retreat loop for a bad waypoint. A
            # confirmed no-progress interval blacklists that goal and replans now.
            if self.target is not None and self.target_kind == "frontier":
                self.unreachable_frontiers.add((int(round(self.target[0])), int(round(self.target[1]))))
            self.recovery.clear(); self.recovery_path = []; self.recovery_target = None
            self.target = None; self.path = []; self.path_index = 0; self.last_plan_goal = None
            self._event("No-progress detected in 0.45 s · target skipped and route replanned")

    def _advance_exploration_target(self):
        if self.phase != "Explore": return
        if self.target is not None and self.target_kind == "frontier" and self._distance(self.target) <= 0.62:
            self.visited_frontiers.add((int(round(self.target[0])), int(round(self.target[1]))))
            self.target = None; self.path = []; self.path_index = 0; self.last_plan_goal = None
        elif self.target is not None and self.target_kind == "wall" and self._distance(self.target) <= 0.62:
            self.target = None; self.path = []; self.path_index = 0; self.last_plan_goal = None
        if self.target is None:
            self._select_goal()

    def _choose_algorithms(self):
        x, y = self.robot.cell
        terrain = int(self.cave.terrain[y, x]) if self.cave.is_walkable(x, y) else 0
        if self.phase == "Return":
            self._switch("Return home", "A*", "Safe return", "battery reserve or science goals reached"); return
        if self.recovery.active:
            self._switch(None, "Dijkstra", "Recovery", "stuck or oscillating robot"); return
        if self.robot.uncertainty > SETTINGS.localization_uncertainty_limit:
            self._switch("Nearest frontier", "Dijkstra", "Loop-closure seeking", "localization uncertainty is high"); return
        if self.belief.change_count - self.previous_map_changes > 120:
            self._switch(None, "D* Lite", "Collision guard", "new obstacles changed the map")
            self.previous_map_changes = self.belief.change_count; return
        if terrain in (3, 4):
            self._switch("Wall-follow", "A*", "Turn-in-place", "narrow or hazardous terrain"); return
        if self._is_open_chamber():
            self._switch("Utility frontier", "Theta*", "Safe waypoint tracking", "open chamber favors any-angle paths"); return
        self._switch("Utility frontier", "A*", "Safe waypoint tracking", "balanced exploration")

    def _select_goal(self):
        start = self.robot.cell; grid = self.belief.plan_grid()
        if self.exploration == "Wall-follow":
            candidate = self.wall.goal(start, grid)
            if candidate is not None and candidate not in self.visited_frontiers and candidate not in self.unreachable_frontiers:
                self.target, self.target_kind = candidate, "wall"
            else:
                self.target = select_frontier(grid, start, "nearest", self.robot.battery, self.cave.cost, self.visited_frontiers | self.unreachable_frontiers)
                self.target_kind = "frontier"
        else:
            strategy = "nearest" if self.exploration == "Nearest frontier" else "utility"
            self.target = select_frontier(grid, start, strategy, self.robot.battery, self.cave.cost, self.visited_frontiers | self.unreachable_frontiers)
            self.target_kind = "frontier"
        if self.target is None:
            self.phase = "Return"; self.target = self.cave.entrance; self.target_kind = "home"; self.path = []
            self._event("No unvisited reachable frontiers remain · returning to skylight"); return
        self.path = []; self.last_plan_goal = None
        # Candidate detections require proximity; the hidden object is not shown beforehand.
        for obj in self.cave.objects:
            if not obj["found"] and self._distance((obj["x"], obj["y"])) < 3.0:
                obj["found"] = True; self.found.append(obj)
                self.phase = "Investigate"; self.target = (obj["x"], obj["y"]); self.target_kind = "science"
                self.path = []; self._event(f"Sensor anomaly · {obj['type'].replace('_',' ')} candidate detected")
                break

    def _investigate(self, dt):
        if self.target is None: self.phase = "Explore"; return
        if self._distance(self.target) > 0.68: return
        obj = next((o for o in self.cave.objects if o["found"] and not o.get("investigated", False) and (o["x"], o["y"]) == tuple(self.target)), None)
        if obj is None:
            self.phase = "Explore"; self.target = None; self.path = []; return
        self.robot.scanning += dt
        needed = 4.0 if obj["kind"] in ("life", "false_positive") else 2.0
        if self.robot.scanning >= needed:
            cost = SETTINGS.life_scan_energy if obj["kind"] in ("life", "false_positive") else SETTINGS.scan_energy
            self.robot.battery = max(0.0, self.robot.battery-cost); self.robot.scan_count += 1
            obj["investigated"] = True
            if obj["kind"] == "mineral":
                self.robot.minerals_found += 1; obj["confirmed"] = True; self._event(f"Mineral confirmed · {obj['type'].replace('_',' ')}")
            elif obj["kind"] == "life":
                obj["confirmed"] = True; self.robot.life_confirmed += 1; self._event("Life signature confirmed · repeat fluorescence positive")
            elif obj["kind"] == "false_positive":
                obj["confirmed"] = False; self._event("False positive rejected · fluorescence did not persist")
            elif obj["kind"] == "ice": self._event("Water-ice signature mapped")
            elif obj["kind"] == "radiation": self._event("Radiation hotspot recorded")
            self.phase = "Explore"; self.target = None; self.target_kind = "frontier"; self.path = []; self.robot.scanning = 0.0

    def _plan_if_needed(self):
        if self.target is None: self.path = []; return
        start = self.robot.cell; goal = (int(round(self.target[0])), int(round(self.target[1])))
        start = (max(0,min(self.cave.width-1,start[0])), max(0,min(self.cave.height-1,start[1])))
        if start == goal:
            self.path = [start]; self.last_plan_goal = goal; return
        target_changed = goal != self.last_plan_goal
        start_lost = bool(self.path) and start not in self.path and self.plan_clock >= 0.35
        planner_changed = self.planner != self.last_planner_used
        active_index = min(max(self.path_index, 0), max(0, len(self.path)-1))
        active_next = self.path[min(active_index+1, len(self.path)-1)] if self.path else None
        next_is_blocked = active_next is not None and not self.cave.is_walkable(*active_next)
        should_plan = (not self.path or target_changed or next_is_blocked or start_lost or planner_changed)
        if not should_plan: return
        grid = self.belief.plan_grid()
        # Preserve the distinction between sensed obstacles and unknown cells. Unknown
        # space is blocked for driving, but must NOT be inflated as if it were rock.
        known_occupied = grid >= 0.72
        # Only known-free cells are driveable; unknown and occupied cells are blocked.
        grid[grid >= 0.35] = 0.95
        # Keep a cell-level safety margin only in the local collision checker. Inflating
        # every wall by a whole grid cell would seal narrow but physically traversable
        # corridors, so the global planner blocks actual occupied cells and forbids
        # diagonal corner-cutting; the robot's swept-footprint guard handles clearance.
        sx, sy = start; grid[sy, sx] = -0.1
        gx, gy = goal
        if not self.cave.is_walkable(gx, gy):
            # Simulator collision truth acts as a contact/near-field safety sensor.
            # Correct the belief so a false-free wall is not selected repeatedly.
            self.belief.mark_occupied(gx, gy)
            self.unreachable_frontiers.add(goal)
            self.target = None; self.path = []; self.path_index = 0; self.last_plan_goal = None
            self._event("Safety check rejected a false-free obstacle · marked occupied")
            return
        # The entrance and travelled trail are safe known cells even if a noisy ray
        # temporarily classified one of them as occupied.
        for px, py in self.robot.trail:
            ix, iy = int(round(px)), int(round(py))
            if 0 <= ix < self.cave.width and 0 <= iy < self.cave.height:
                grid[iy, ix] = -0.1
        # Contact-confirmed obstacles are immutable in the belief map; repeated noisy
        # LiDAR rays must not turn a collided-with wall back into a free cell.
        for bx, by in self.collision_blocked:
            if 0 <= bx < self.cave.width and 0 <= by < self.cave.height:
                grid[by, bx] = 0.95
        if self.phase == "Return": grid[self.cave.entrance[1], self.cave.entrance[0]] = -0.1
        cost = self.cave.cost.copy()
        if self.planner == "D* Lite": self.path, self.expanded = self.dstar.plan(grid, start, goal, cost)
        else:
            method = {"A*":"astar", "Dijkstra":"dijkstra", "Theta*":"theta"}.get(self.planner, "astar")
            self.path, self.expanded = plan_grid(grid, start, goal, cost, method)
        if not self.path and self.planner != "A*":
            self._switch(planner="A*", reason="fallback after selected planner found no safe route")
            self.path, self.expanded = plan_grid(grid, start, goal, cost, "astar")
        if not self.path and self.phase == "Return":
            self.path = self._trail_return_path()
            if self.path: self._event("Planner fallback · following previously traversed safe trail")
        self.path_index = 0
        if not self.path:
            if self.phase == "Return":
                self.path = self._trail_return_path()
            else:
                self.unreachable_frontiers.add(goal)
                self.target = None; self.target_kind = "frontier"
                self._event("Frontier has no known-safe route · skipping and trying another branch")
        else:
            self.no_route_count = 0
        self.last_plan_goal = goal; self.last_plan_start = start
        self.last_plan_change_count = self.belief.change_count; self.last_planner_used = self.planner; self.plan_clock = 0.0

    def _trail_return_path(self):
        trail = [(int(round(x)), int(round(y))) for x, y in self.robot.trail]
        if not trail: return []
        idx = min(range(len(trail)), key=lambda i: math.hypot(trail[i][0]-self.robot.x, trail[i][1]-self.robot.y))
        seq = list(reversed(trail[:idx+1]))
        clean = []
        for p in seq:
            if self.cave.is_walkable(*p) and (not clean or p != clean[-1]): clean.append(p)
        if clean and clean[0] != self.robot.cell: clean.insert(0, self.robot.cell)
        if clean and clean[-1] != self.cave.entrance: clean.append(self.cave.entrance)
        return clean

    def _next_waypoint(self):
        """Follow a monotonic waypoint index to avoid oscillating between cell centers."""
        if not self.path: return None
        if len(self.path) == 1:
            return self.target if self.target is not None and self._distance(self.target) > 0.45 else None
        self.path_index = max(0, min(self.path_index, len(self.path)-1))
        # First align to the current grid cell's center if odometry left us off-center.
        if self.path_index == 0:
            first = self.path[0]
            if math.hypot(first[0]-self.robot.x, first[1]-self.robot.y) > 0.18:
                return first
            self.path_index = 1
        # Advance only when the active waypoint is reached. Never switch back to a
        # previous node just because rounding moves the robot into a neighboring cell.
        while self.path_index < len(self.path)-1:
            point = self.path[self.path_index]
            if math.hypot(point[0]-self.robot.x, point[1]-self.robot.y) > 0.22: break
            self.path_index += 1
        return self.path[self.path_index]

    def _handle_collision(self, waypoint):
        wx, wy = int(round(waypoint[0])), int(round(waypoint[1]))
        newly_blocked = set()
        if not self.cave.is_walkable(wx, wy): newly_blocked.add((wx, wy))
        # Mark local ground-truth walls after contact. This is a simulated tactile
        # safety observation, not advance knowledge of unexplored cave geometry.
        cx, cy = self.robot.cell
        for y in range(max(0,cy-1), min(self.cave.height,cy+2)):
            for x in range(max(0,cx-1), min(self.cave.width,cx+2)):
                if not self.cave.is_walkable(x,y): newly_blocked.add((x,y))
        for x, y in newly_blocked:
            self.collision_blocked.add((x,y)); self.belief.mark_occupied(x,y)
        self.path = []; self.path_index = 0; self.last_plan_goal = None; self.plan_clock = 1.0
        self._switch(None, "D* Lite", "Collision guard", "contact detected · obstacle marked and route replanned")
        if newly_blocked and self.mission_time-self.last_collision_event_time >= 1.0:
            self._event("Collision guard · obstacle locked in map; route replanning")
            self.last_collision_event_time = self.mission_time

    def _run_recovery(self, dt):
        """Retrace the actual traversed trail point-by-point to escape deadlocks."""
        if not self.recovery_path:
            trail = list(self.robot.trail)
            if len(trail) >= 3:
                idx = min(range(len(trail)), key=lambda i: (trail[i][0]-self.robot.x)**2+(trail[i][1]-self.robot.y)**2)
                # Reverse only the recently traversed segment; every waypoint was reached safely.
                segment = list(reversed(trail[:max(1, idx)]))
                self.recovery_path = []
                total = 0.0; previous = (self.robot.x, self.robot.y)
                for point in segment:
                    if not self.cave.can_occupy(point[0], point[1], 0.18): continue
                    step = math.hypot(point[0]-previous[0], point[1]-previous[1])
                    total += step; previous = point
                    # Follow dense trail samples individually around tight cave bends.
                    self.recovery_path.append(point)
                    if total >= 2.2: break
            self.recovery_index = 0; self.recovery_distance = 0.0
            self._switch(None, "A*", "Recovery", "stuck detected · retracing known-safe trail")
        # A retreat waypoint must be reachable within a practical tolerance; exact
        # coordinate equality is unrealistic with acceleration, collision and dt limits.
        if self.recovery_path and self.recovery_index >= len(self.recovery_path):
            self.recovery.clear(); self.recovery_path=[]; self.recovery_target=None
            self.target=None; self.path=[]; self.path_index=0; self.last_plan_goal=None
            self._event("Recovery complete · replanning from a known-safe trail")
            return
        if not self.recovery_path:
            # Last-resort local escape checks candidate moves once and holds that
            # waypoint until reached; changing the waypoint every frame causes jitter.
            if self.recovery_target is None:
                candidates = [(self.robot.x+dx, self.robot.y+dy) for dx,dy in
                              ((-0.8,0),(0,-0.8),(0.8,0),(0,0.8),(-0.6,-0.6),(0.6,-0.6),(-0.6,0.6),(0.6,0.6))]
                safe = [p for p in candidates if self.cave.can_occupy(p[0],p[1],0.18)]
                if safe:
                    walls = self._nearby_walls()
                    self.recovery_target = max(safe, key=lambda p: min((p[0]-wx)**2+(p[1]-wy)**2 for wx,wy in walls) if walls else 0.0)
            if self.recovery_target is not None:
                vx,vy = steer((self.robot.x,self.robot.y), self.recovery_target, (), speed=0.7)
                self.robot.update((self.robot.x+vx,self.robot.y+vy), self.cave, dt, speed=0.4)
                if math.hypot(self.robot.x-self.recovery_target[0],self.robot.y-self.recovery_target[1]) < 0.25:
                    self.recovery.clear(); self.recovery_target=None; self.target=None; self.path=[]
                    self._event("Local recovery complete · replanning from safe cell")
            else:
                self.recovery.clear(); self.target=None; self.path=[]
                self._event("Recovery could not find a safe step · forcing fresh map plan")
            return
        target = self.recovery_path[min(self.recovery_index, len(self.recovery_path)-1)]
        if math.hypot(self.robot.x-target[0], self.robot.y-target[1]) < 0.22:
            self.recovery_index += 1
            if self.recovery_index >= len(self.recovery_path):
                self.recovery.clear(); self.recovery_path=[]; self.recovery_target=None
                self.target=None; self.path=[]; self.path_index=0; self.last_plan_goal=None
                self._event("Recovery complete · resumed exploration from a known-safe trail")
                return
            target = self.recovery_path[self.recovery_index]
        # No repulsion during a validated reverse-trail maneuver: wall forces must not
        # push the robot away from the path it already proved traversable.
        vx,vy = steer((self.robot.x,self.robot.y), target, (), speed=0.6)
        self.robot.update((self.robot.x+vx,self.robot.y+vy), self.cave, dt, speed=0.38)

    def _distance(self, p): return math.hypot(self.robot.x-p[0], self.robot.y-p[1])

    def _is_narrow(self):
        x,y = self.robot.cell
        walls = sum(1 for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)) if not self.cave.is_walkable(x+dx,y+dy))
        return walls >= 2

    def _is_open_chamber(self):
        x,y = self.robot.cell
        count = sum(1 for dy in range(-2,3) for dx in range(-2,3) if self.cave.is_walkable(x+dx,y+dy))
        return count >= 21

    def _nearby_walls(self):
        x,y = self.robot.x,self.robot.y; out=[]
        for dx in range(-2,3):
            for dy in range(-2,3):
                wx,wy = int(round(x+dx)),int(round(y+dy))
                if not self.cave.is_walkable(wx,wy): out.append((wx,wy))
        return out
