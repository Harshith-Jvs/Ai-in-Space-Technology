"""Cave Explorer desktop simulation. Run with: python main.py"""
from __future__ import annotations
import argparse, csv, json, math, os, random, sys, time
from pathlib import Path
import numpy as np
import pygame
from config import SETTINGS, DIFFICULTIES, COLORS
from cave_gen import Cave, WALL, FLOOR, RUBBLE, SQUEEZE, PIT
from mapping import OccupancyMap
from robot import ScoutRobot
from controller import MissionController
from effects import Effects
from ui import text, panel, draw_hud, draw_minimap, draw_summary

BASE=Path(__file__).resolve().parent

def build(seed,difficulty):
    w,h=DIFFICULTIES[difficulty]; cave=Cave(w,h,seed); belief=OccupancyMap(w,h)
    robot=ScoutRobot(cave.entrance); controller=MissionController(cave,robot,belief)
    return cave,belief,robot,controller

def export_map(cave, belief, robot, controller):
    """Persist the robot's belief map for later inspection/downlink."""
    out = BASE / "reports"
    out.mkdir(exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    stem = f"mapped_cave_seed{cave.seed}_{stamp}"
    probability = belief.probability.astype(np.float32)
    np.savez_compressed(
        out / f"{stem}.npz",
        occupancy_probability=probability,
        seen=belief.seen.astype(np.uint8),
        robot_pose=np.asarray([robot.x, robot.y, robot.heading], dtype=np.float32),
        entrance=np.asarray(cave.entrance, dtype=np.int32),
        seed=np.asarray(cave.seed, dtype=np.int64),
        coverage=np.asarray(controller._cave_coverage(), dtype=np.float32),
        observed_grid_fraction=np.asarray(controller._observed_grid_fraction(), dtype=np.float32),
        robot_trail=np.asarray(robot.trail, dtype=np.float32),
        planned_path=np.asarray(controller.path, dtype=np.int32),
        collision_blocked=np.asarray(sorted(controller.collision_blocked), dtype=np.int32).reshape(-1, 2),
    )
    # PNG uses only the robot's belief; it does not reveal unobserved ground truth.
    scale = 8
    image = pygame.Surface((cave.width * scale, cave.height * scale))
    image.fill((14, 19, 27))
    for y in range(cave.height):
        for x in range(cave.width):
            if not belief.seen[y, x]:
                col = (14, 19, 27)
            else:
                prob = float(probability[y, x])
                if prob < 0.35: col = (83, 119, 115)
                elif prob > 0.68: col = (151, 89, 72)
                else: col = (153, 137, 94)
            pygame.draw.rect(image, col, (x * scale, y * scale, scale, scale))
    ex, ey = cave.entrance
    pygame.draw.circle(image, (255, 205, 120), (ex * scale + scale // 2, ey * scale + scale // 2), scale)
    rx, ry = int(round(robot.x)), int(round(robot.y))
    pygame.draw.circle(image, (80, 224, 235), (rx * scale + scale // 2, ry * scale + scale // 2), max(3, scale // 2))
    pygame.image.save(image, out / f"{stem}.png")
    metadata = {
        "seed": cave.seed, "width_cells": cave.width, "height_cells": cave.height,
        "coordinate_convention": "x increases right; y increases down; integer coordinates are cell centers",
        "map_type": "robot_belief_occupancy_grid",
        "occupancy_probability": "0 is free, 1 is occupied; unseen cells are indicated by seen=false",
        "coverage_of_traversable_cells": controller._cave_coverage(),
        "observed_fraction_of_entire_grid": controller._observed_grid_fraction(),
        "seen_cells": int(belief.seen.sum()),
        "robot_pose": {"x": robot.x, "y": robot.y, "heading_rad": robot.heading},
        "mission_phase": controller.phase,
        "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    (out / f"{stem}.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return out / f"{stem}.png", out / f"{stem}.npz", out / f"{stem}.json"

def save_checkpoint(cave, belief, robot, controller):
    """Atomically save the current robot-side map at a stable per-seed path."""
    out = BASE / "reports"
    out.mkdir(exist_ok=True)
    stem = f"checkpoint_seed{cave.seed}"
    tmp = out / f"{stem}.tmp.npz"
    np.savez_compressed(
        tmp,
        occupancy_probability=belief.probability.astype(np.float32),
        seen=belief.seen.astype(np.uint8),
        robot_pose=np.asarray([robot.x, robot.y, robot.heading], dtype=np.float32),
        entrance=np.asarray(cave.entrance, dtype=np.int32),
        seed=np.asarray(cave.seed, dtype=np.int64),
        cave_floor_coverage=np.asarray(controller._cave_coverage(), dtype=np.float32),
        observed_grid_fraction=np.asarray(controller._observed_grid_fraction(), dtype=np.float32),
        robot_trail=np.asarray(robot.trail, dtype=np.float32),
        planned_path=np.asarray(controller.path, dtype=np.int32),
        collision_blocked=np.asarray(sorted(controller.collision_blocked), dtype=np.int32).reshape(-1, 2),
    )
    final = out / f"{stem}.npz"
    os.replace(tmp, final)
    metadata = {
        "seed": cave.seed, "mission_phase": controller.phase,
        "cave_floor_coverage_evaluation_only": controller._cave_coverage(),
        "observed_grid_fraction": controller._observed_grid_fraction(),
        "seen_cells": int(belief.seen.sum()),
        "width_cells": cave.width, "height_cells": cave.height,
        "robot_pose": {"x": robot.x, "y": robot.y, "heading_rad": robot.heading},
        "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    (out / f"{stem}.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return final


def export_report(cave, belief, robot, controller):
    out = BASE / "reports"
    out.mkdir(exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    data = {
        "seed": cave.seed, "phase": controller.phase,
        "mission_time_s": round(controller.mission_time, 2),
        "coverage_of_traversable_cells": controller._cave_coverage(),
        "observed_fraction_of_entire_grid": controller._observed_grid_fraction(),
        "mapped_cells": int(np.count_nonzero(belief.seen & cave.walkable_mask)),
        "total_traversable_cells": int(cave.walkable_mask.sum()),
        "battery": robot.battery, "minerals_found": robot.minerals_found,
        "life_confirmed": robot.life_confirmed,
        "algorithm_switches": [{"time": round(t, 2), "event": e} for t, e in controller.switches],
        "events": controller.events,
        "found_objects": [{k: v for k, v in o.items()} for o in controller.found],
        "algorithm_usage": dict(controller.usage),
    }
    report_path = out / f"report_{stamp}.json"
    report_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    with (out / f"switches_{stamp}.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f); writer.writerow(["mission_time_s", "event"]); writer.writerows(controller.switches)
    return report_path

def main():
    parser=argparse.ArgumentParser(description="Autonomous Martian lava-tube exploration simulation")
    parser.add_argument("--seed",type=int,default=None);parser.add_argument("--difficulty",choices=list(DIFFICULTIES),default="Medium")
    args=parser.parse_args();seed=args.seed if args.seed is not None else random.randint(10000,999999)
    pygame.init();pygame.display.set_caption("Cave Explorer · Autonomous Mars Robotics")
    screen=pygame.display.set_mode((1280,720),pygame.RESIZABLE);clock=pygame.time.Clock()
    cave,belief,robot,controller=build(seed,args.difficulty);effects=Effects()
    running=True;paused=False;speed=1.0;truth=False;fog=True;lighting=True;minimap=True;debug=False;fullscreen=False;tab="overview"
    terminal_saved=False;sim_accumulator=0.0;menu=True;difficulty=args.difficulty;seed_input=str(seed);sensor_clock=0.0;render_clock=0.0;camera=(0.0,0.0);zoom=1.0;dragging=False;drag_start=None;pan=(0.0,0.0);last_mouse=(0,0)
    checkpoint_clock = 0.0
    while running:
        frame_dt=min(clock.tick(SETTINGS.fps_limit)/1000.0,0.08);fps=clock.get_fps()
        w,h=screen.get_size();world_w=max(200,w-300);world_h=h
        for event in pygame.event.get():
            if event.type==pygame.QUIT:running=False
            elif event.type==pygame.VIDEORESIZE and not fullscreen:screen=pygame.display.set_mode((max(900,event.w),max(600,event.h)),pygame.RESIZABLE)
            elif event.type==pygame.MOUSEWHEEL and not menu:zoom=max(.55,min(2.7,zoom*(1.12 if event.y>0 else 1/1.12)))
            elif event.type==pygame.MOUSEBUTTONDOWN and event.button==2:dragging=True;drag_start=event.pos;last_mouse=event.pos
            elif event.type==pygame.MOUSEBUTTONUP and event.button==2:dragging=False
            elif event.type==pygame.MOUSEMOTION and dragging:
                pan=(pan[0]+event.pos[0]-last_mouse[0],pan[1]+event.pos[1]-last_mouse[1]);last_mouse=event.pos
            elif event.type==pygame.KEYDOWN:
                if event.key==pygame.K_ESCAPE:
                    if menu:running=False
                    else:menu=True
                elif menu:
                    if event.key==pygame.K_RETURN:
                        try:seed=int(seed_input)
                        except ValueError:seed=random.randint(10000,999999)
                        cave,belief,robot,controller=build(seed,difficulty);effects=Effects();menu=False;paused=False;sensor_clock=0;pan=(0,0);zoom=1;terminal_saved=False;sim_accumulator=0.0
                    elif event.key==pygame.K_1:difficulty="Small"
                    elif event.key==pygame.K_2:difficulty="Medium"
                    elif event.key==pygame.K_3:difficulty="Large"
                    elif event.key==pygame.K_BACKSPACE:seed_input=seed_input[:-1]
                    elif event.unicode.isdigit() and len(seed_input)<10:seed_input+=event.unicode
                else:
                    if event.key==pygame.K_SPACE:paused=not paused
                    elif event.key in (pygame.K_EQUALS,pygame.K_PLUS,pygame.K_KP_PLUS):speed=min(8.0,speed*2)
                    elif event.key in (pygame.K_MINUS,pygame.K_KP_MINUS):speed=max(.25,speed/2)
                    elif event.key==pygame.K_r:
                        seed=random.randint(10000,999999);cave,belief,robot,controller=build(seed,difficulty);effects=Effects();pan=(0,0);zoom=1;terminal_saved=False;sim_accumulator=0.0
                    elif event.key==pygame.K_s:
                        cave,belief,robot,controller=build(seed,difficulty);effects=Effects();pan=(0,0);zoom=1;terminal_saved=False;sim_accumulator=0.0
                    elif event.key==pygame.K_a:controller.set_auto()
                    elif event.key in (pygame.K_1,pygame.K_2,pygame.K_3,pygame.K_4,pygame.K_5,pygame.K_6,pygame.K_7):controller.force_algorithm(event.unicode)
                    elif event.key==pygame.K_t:truth=not truth
                    elif event.key==pygame.K_f:fog=not fog
                    elif event.key==pygame.K_l:lighting=not lighting;robot.light=lighting
                    elif event.key==pygame.K_m:minimap=not minimap
                    elif event.key==pygame.K_g:debug=not debug
                    elif event.key==pygame.K_TAB:tab="switches" if tab!="switches" else "overview"
                    elif event.key==pygame.K_F11:
                        fullscreen=not fullscreen
                        screen=pygame.display.set_mode((0,0),pygame.FULLSCREEN) if fullscreen else pygame.display.set_mode((1280,720),pygame.RESIZABLE)
                    elif event.key==pygame.K_e:
                        path=export_report(cave,belief,robot,controller); map_paths=export_map(cave,belief,robot,controller);controller._event(f"Report + map exported · {path.name}")
        if menu:
            screen.fill((8,12,19));panel(screen,pygame.Rect(w//2-260,h//2-235,520,470))
            text(screen,"CAVE EXPLORER",(w//2-155,h//2-190),31,COLORS['cyan'],True)
            text(screen,"AUTONOMOUS MARS LAVA-TUBE ROBOTICS SIMULATION",(w//2-220,h//2-147),12,COLORS['muted'])
            text(screen,"Choose cave size  (1 / 2 / 3)",(w//2-210,h//2-90),16)
            for i,d in enumerate(DIFFICULTIES):
                col=COLORS['cyan'] if d==difficulty else COLORS['muted'];text(screen,f"{i+1}  {d}  {DIFFICULTIES[d][0]} × {DIFFICULTIES[d][1]}",(w//2-190,h//2-56+i*30),16,col)
            text(screen,"Seed (type digits; same seed = same cave)",(w//2-210,h//2+65),15)
            pygame.draw.rect(screen,(35,46,60),(w//2-190,h//2+95,380,42),border_radius=8);text(screen,seed_input,(w//2-174,h//2+105),19)
            text(screen,"ENTER  Start mission",(w//2-90,h//2+168),18,COLORS['green'],True)
            text(screen,"ESC  Quit",(w//2-42,h//2+205),13,COLORS['muted'])
            pygame.display.flip();continue
        if not paused and not controller.completed and not controller.failed:
            # Fixed-step simulation is independent of render FPS. Cap catch-up work
            # so a slow frame cannot spiral into an unbounded update backlog.
            sim_accumulator = min(sim_accumulator + frame_dt * speed, SETTINGS.fixed_dt * 8)
            steps = 0
            while sim_accumulator >= SETTINGS.fixed_dt and steps < 8:
                subdt = SETTINGS.fixed_dt
                controller.update(subdt); sensor_clock += subdt; checkpoint_clock += subdt
                while sensor_clock >= 0.24:
                    sensor_clock -= 0.24
                    robot.lidar = belief.scan(cave, (robot.x, robot.y), SETTINGS.lidar_rays,
                                              SETTINGS.lidar_range, SETTINGS.lidar_noise,
                                              np.random.default_rng(cave.seed + int(controller.mission_time * 1000)))
                if checkpoint_clock >= 10.0:
                    checkpoint_clock = 0.0
                    try:
                        save_checkpoint(cave, belief, robot, controller)
                    except (OSError, ValueError) as exc:
                        controller._event(f"Checkpoint warning · {exc}")
                effects.update(subdt, robot)
                sim_accumulator -= SETTINGS.fixed_dt; steps += 1
        if (controller.completed or controller.failed) and not terminal_saved:
            controller._event("Auto-saving mission report and mapped cave for Earth downlink")
            try:
                export_report(cave, belief, robot, controller)
                export_map(cave, belief, robot, controller)
            except (OSError, pygame.error) as exc:
                controller._event(f"Auto-save warning · {exc}")
            terminal_saved = True
        screen.fill(COLORS['background'])
        cell=min(world_w/cave.width,world_h/cave.height)*zoom
        cell=max(4,min(26,cell));map_px=cave.width*cell;map_py=cave.height*cell
        # Camera eases toward the robot while allowing middle-mouse panning.
        if zoom <= 1.03:
            desired_x=(world_w-map_px)/2+pan[0];desired_y=(world_h-map_py)/2+pan[1]
        else:
            desired_x=world_w/2-robot.x*cell+pan[0];desired_y=world_h/2-robot.y*cell+pan[1]
        camera=(camera[0]+(desired_x-camera[0])*min(1,frame_dt*SETTINGS.camera_ease),camera[1]+(desired_y-camera[1])*min(1,frame_dt*SETTINGS.camera_ease))
        # Keep the entrance in frame near deployment and the cave in view when zoomed out.
        ox,oy=int(camera[0]),int(camera[1])
        def to_screen(x,y):return (int(ox+(x+.5)*cell),int(oy+(y+.5)*cell))
        # Ground-truth terrain is rendered only where the robot has mapped it unless truth overlay is enabled.
        for yy in range(cave.height):
            for xx in range(cave.width):
                sx=int(ox+xx*cell);sy=int(oy+yy*cell)
                if sx>world_w or sy>h or sx+cell<0 or sy+cell<0:continue
                seen=belief.seen[yy,xx];terrain=int(cave.terrain[yy,xx])
                # The viewer sees a continuous rock boundary and dark passage floor,
                # rather than a checkerboard of indistinguishable mystery squares.
                # Fog still controls scientific-map visibility; T reveals truth outlines.
                texture=((xx*17 + yy*31 + cave.seed) % 11) - 5
                if terrain==WALL:
                    col=(max(20,39+texture),max(17,27+texture//2),max(16,25+texture//2)) if (seen or truth or not fog) else (max(13,25+texture//2),max(13,20+texture//2),max(14,22+texture//2))
                elif terrain==PIT:
                    col=(9,10,15) if (seen or truth or not fog) else (10,13,18)
                elif not seen and not truth and fog:
                    col=(9,12,18)
                elif terrain==RUBBLE:
                    col=(113+texture,75+texture,57+texture)
                elif terrain==SQUEEZE:
                    col=(102+texture,82+texture,64+texture)
                else:
                    col=(53+texture,45+texture,42+texture) if seen or truth or not fog else (10,13,18)
                pygame.draw.rect(screen,col,(sx,sy,max(1,int(cell)+1),max(1,int(cell)+1)))
                if terrain==WALL and (seen or truth or not fog) and cell>8:
                    # Subtle flecks make wall mass read as rock, not a grid obstacle tile.
                    fleck=(max(18,col[0]-10),max(16,col[1]-7),max(15,col[2]-6))
                    pygame.draw.circle(screen,fleck,(sx+int(cell*.27),sy+int(cell*.31)),max(1,int(cell*.08)))
                    if (xx+yy)%3==0:pygame.draw.line(screen,(col[0]+4,col[1]+3,col[2]+3),(sx+int(cell*.2),sy+int(cell*.72)),(sx+int(cell*.68),sy+int(cell*.58)),1)
                if terrain==RUBBLE and cell>7 and (seen or truth or not fog):
                    pygame.draw.circle(screen,(155,111,83),(sx+int(cell*.5),sy+int(cell*.5)),max(2,int(cell*.28)))
                    pygame.draw.arc(screen,(75,53,43),(sx+int(cell*.2),sy+int(cell*.2),int(cell*.6),int(cell*.55)),0.2,2.7,1)
                if terrain==SQUEEZE and cell>8 and (seen or truth or not fog):
                    pygame.draw.line(screen,(153,116,83),(sx+int(cell*.12),sy+int(cell*.18)),(sx+int(cell*.88),sy+int(cell*.18)),1)
                if terrain==PIT and cell>6 and (seen or truth or not fog):
                    pygame.draw.ellipse(screen,(3,4,8),(sx+int(cell*.12),sy+int(cell*.12),int(cell*.76),int(cell*.76)))
                    pygame.draw.ellipse(screen,(106,83,74),(sx+int(cell*.12),sy+int(cell*.12),int(cell*.76),int(cell*.76)),1)
                if debug and seen:pygame.draw.rect(screen,(84,98,115),(sx,sy,int(cell),int(cell)),1)
                if truth and terrain==WALL:pygame.draw.rect(screen,(120,95,95),(sx,sy,int(cell),int(cell)),1)
        # Skylight and sunlight shaft.
        ex,ey=to_screen(*cave.entrance);pygame.draw.circle(screen,(255,195,121),(ex,ey),max(5,int(cell*1.8)))
        pygame.draw.circle(screen,(255,226,172),(ex,ey),max(2,int(cell*.85)))
        pygame.draw.line(screen,(139,105,75),(ex,0),(ex,ey),max(1,int(cell*.7)))
        # Science targets are revealed only after a nearby sensor hit.
        for obj in cave.objects:
            if not obj['found'] and not truth:continue
            sx,sy=to_screen(obj['x'],obj['y'])
            if obj['kind']=='mineral':col={'silica':COLORS['mineral_silica'],'iron_oxide':COLORS['mineral_iron'],'hydrated_mineral':COLORS['mineral_hydrated']}.get(obj['type'],COLORS['cyan'])
            elif obj['kind']=='life':col=COLORS['life']
            elif obj['kind']=='false_positive':col=(116,137,157)
            elif obj['kind']=='ice':col=(139,203,255)
            else:col=COLORS['danger']
            pygame.draw.circle(screen,col,(sx,sy),max(3,int(cell*.28)))
            if obj['kind']=='life':pygame.draw.circle(screen,col,(sx,sy),max(5,int(cell*.65)),1)
        # Robot trail and planned path.
        if len(robot.trail)>1:
            points=[to_screen(x,y) for x,y in robot.trail]
            pygame.draw.lines(screen,(*robot.color,),False,points,2)
        if controller.path and (debug or True):
            points=[to_screen(x,y) for x,y in controller.path]
            if len(points)>1:pygame.draw.lines(screen,(76,207,221),False,points,max(1,int(cell*.12)))
        if debug:
            for x,y in controller.expanded[::max(1,len(controller.expanded)//350)]:
                sx,sy=to_screen(x,y);pygame.draw.circle(screen,(92,128,172),(sx,sy),max(1,int(cell*.1)))
            for x,y in controller.path:
                sx,sy=to_screen(x,y);pygame.draw.circle(screen,(112,226,235),(sx,sy),max(2,int(cell*.14)))
            if robot.lidar:
                for x,y in robot.lidar:pygame.draw.line(screen,(68,157,178),to_screen(robot.x,robot.y),to_screen(x,y),1)
        effects.draw(screen,to_screen,cell)
        robot.draw(screen,to_screen,cell)
        # Simulated headlight cone, clipped approximately by dimming the unmapped world.
        if lighting:
            darkness=pygame.Surface((world_w,h),pygame.SRCALPHA);darkness.fill((2,4,10,45 if not fog else 70))
            screen.blit(darkness,(0,0))
            sx,sy=to_screen(robot.x,robot.y); cone=pygame.Surface((world_w,h),pygame.SRCALPHA)
            pygame.draw.circle(cone,(0,0,0,0),(sx,sy),int(cell*SETTINGS.lidar_range))
            # Subtle forward beam using a transparent polygon.
            angle=robot.heading; length=cell*SETTINGS.lidar_range
            p1=(sx,sy);p2=(sx+math.cos(angle-.48)*length,sy+math.sin(angle-.48)*length);p3=(sx+math.cos(angle+.48)*length,sy+math.sin(angle+.48)*length)
            pygame.draw.polygon(cone,(20,35,43,25),(p1,p2,p3));screen.blit(cone,(0,0))
        if minimap:draw_minimap(screen,cave,robot,belief,pygame.Rect(14,14,180,112))
        if tab=="switches":
            panel(screen,pygame.Rect(14,138,290,min(350,h-155)))
            text(screen,"ALGORITHM SWITCH LOG",(28,151),13,COLORS['cyan'],True)
            for i,(tm,msg) in enumerate(controller.switches[-10:]):
                text(screen,f"{tm:5.1f}s {msg[:28]}",(28,178+i*25),10)
        elif tab=="stats":
            panel(screen,pygame.Rect(14,138,270,190));text(screen,"LIVE METRICS",(28,151),13,COLORS['cyan'],True)
            text(screen,f"Map cells observed: {belief.seen.sum()}",(28,180),13);text(screen,f"LiDAR updates: {belief.change_count}",(28,204),13)
            text(screen,f"Localization σ: {robot.uncertainty:.2f}",(28,228),13);text(screen,f"Planner expansions: {len(controller.expanded)}",(28,252),13)
        draw_hud(screen,robot,controller,seed,fps,tab,truth,paused,speed)
        if controller.completed or controller.failed:draw_summary(screen,robot,controller,seed)
        pygame.display.flip()
    # Save the latest map even if the user exits before the mission ends.
    try:
        save_checkpoint(cave, belief, robot, controller)
    except (OSError, ValueError, NameError) as exc:
        print(f"Could not save final checkpoint: {exc}")
    pygame.quit()

if __name__=="__main__":main()
