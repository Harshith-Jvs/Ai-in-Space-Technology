"""Rendering helpers for the HUD, minimap, and mission summary."""
import math, pygame
from config import COLORS

FONT_CACHE={}
def font(size,bold=False):
    key=(size,bold)
    if key not in FONT_CACHE: FONT_CACHE[key]=pygame.font.SysFont("segoeui,arial,dejavusans",size,bold=bold)
    return FONT_CACHE[key]
def text(surface,string,pos,size=16,color=None,bold=False):
    surface.blit(font(size,bold).render(str(string),True,color or COLORS['text']),pos)
def panel(surface,rect,color=None,radius=12):
    shadow=pygame.Surface((rect.width+10,rect.height+10),pygame.SRCALPHA);pygame.draw.rect(shadow,(0,0,0,100),shadow.get_rect(),border_radius=radius)
    surface.blit(shadow,(rect.x-4,rect.y+3));pygame.draw.rect(surface,color or COLORS['panel'],rect,border_radius=radius)
    pygame.draw.rect(surface,(53,65,80),rect,1,border_radius=radius)
def bar(surface,x,y,w,h,value,color,label):
    pygame.draw.rect(surface,(42,49,61),(x,y,w,h),border_radius=5);pygame.draw.rect(surface,color,(x,y,int(w*max(0,min(1,value))),h),border_radius=5)
    text(surface,label,(x,y-20),13)
def draw_hud(surface,robot,controller,seed,fps,tab,truth,paused,speed):
    w,h=surface.get_size(); px=w-304; panel(surface,pygame.Rect(px,12,292,h-24))
    text(surface,"CAVE EXPLORER",(px+16,22),20,bold=True)
    text(surface,f"MARS LAVA TUBE  /  SEED {seed}",(px+16,49),11,COLORS['muted'])
    text(surface,f"MISSION: {controller.phase.upper()}",(px+16,75),14,COLORS['cyan'],True)
    bar(surface,px+16,116,260,12,robot.battery/100,COLORS['green'] if robot.battery>30 else COLORS['danger'],f"BATTERY  {robot.battery:05.1f}%")
    bar(surface,px+16,160,260,9,controller._cave_coverage(),COLORS['cyan'],f"CAVE MAPPED  {controller._cave_coverage()*100:.1f}%")
    text(surface,f"TIME {int(controller.mission_time//60):02d}:{int(controller.mission_time%60):02d}   FPS {fps:02.0f}",(px+16,187),13)
    text(surface,f"MINERALS {robot.minerals_found}    LIFE {robot.life_confirmed}",(px+16,210),13)

    # High-contrast active algorithm panel: names, selection mode, and reason are
    # deliberately explicit so viewers can follow the adaptive controller live.
    card=pygame.Rect(px+10,236,272,166)
    pygame.draw.rect(surface,(13,24,34),card,border_radius=10)
    pygame.draw.rect(surface,COLORS['cyan'] if controller.auto else COLORS['warning'],card,2,border_radius=10)
    mode="AUTO · ADAPTIVE" if controller.auto else "MANUAL · OVERRIDE"
    text(surface,"ACTIVE ALGORITHMS",(px+20,246),13,COLORS['cyan'],True)
    text(surface,mode,(px+20,267),11,COLORS['green'] if controller.auto else COLORS['warning'],True)
    text(surface,"EXPLORATION",(px+20,291),10,COLORS['muted'],True)
    text(surface,controller.exploration,(px+118,289),12,COLORS['text'],True)
    text(surface,"PATH PLANNER",(px+20,316),10,COLORS['muted'],True)
    text(surface,controller.planner,(px+118,314),13,COLORS['cyan'],True)
    text(surface,"LOCAL CONTROL",(px+20,341),10,COLORS['muted'],True)
    text(surface,controller.local,(px+118,339),12,COLORS['text'],True)
    reason=str(getattr(controller,"last_reason","Waiting for context"))
    if len(reason)>37: reason=reason[:35]+"…"
    text(surface,"WHY: "+reason,(px+20,371),10,COLORS['warning'])

    text(surface,"RECENT EVENTS",(px+16,421),12,COLORS['muted'],True)
    for i,event in enumerate(controller.events[-6:]):
        msg=event[9:]
        if len(msg)>39:msg=msg[:37]+"…"
        text(surface,msg,(px+16,444+i*20),10,COLORS['text'] if i==len(controller.events[-6:])-1 else COLORS['muted'])
    pygame.draw.line(surface,(53,65,80),(px+14,h-132),(w-24,h-132),1)
    text(surface,f"TAB: {tab.upper()}  |  {('PAUSED' if paused else f'{speed:g}x SIM')}",(px+16,h-116),11,COLORS['warning'] if paused else COLORS['green'])
    text(surface,"SPACE pause · +/- speed · A auto",(px+16,h-94),10,COLORS['muted'])
    text(surface,"1 nearest · 2 utility · 3 wall-follow",(px+16,h-75),10,COLORS['muted'])
    text(surface,"4 Dijkstra · 5 D* Lite · 6 Theta*",(px+16,h-56),10,COLORS['muted'])
    text(surface,"7 A* · T truth · G debug · E export",(px+16,h-37),10,COLORS['muted'])
    text(surface,"R new cave · S replay · F11 fullscreen",(px+16,h-18),10,COLORS['muted'])

def draw_minimap(surface,cave,robot,belief,rect):
    pygame.draw.rect(surface,(8,11,17),rect,border_radius=6)
    cw=rect.width/cave.width;ch=rect.height/cave.height
    for y in range(cave.height):
        for x in range(cave.width):
            col=(12,16,23)
            if belief.seen[y,x]:col=(55,85,91) if belief.probability[y,x]<.45 else (75,57,55)
            pygame.draw.rect(surface,col,(rect.x+x*cw,rect.y+y*ch,max(1,cw),max(1,ch)))
    pygame.draw.circle(surface,COLORS['robot'],(int(rect.x+robot.x*cw),int(rect.y+robot.y*ch)),max(2,int(cw*1.4)))
def draw_summary(surface,robot,controller,seed):
    w,h=surface.get_size(); overlay=pygame.Surface((w,h),pygame.SRCALPHA);overlay.fill((4,7,12,210));surface.blit(overlay,(0,0))
    panel(surface,pygame.Rect(w//2-250,h//2-220,500,440))
    title="MISSION COMPLETE" if controller.completed else "MISSION FAILED"
    text(surface,title,(w//2-150,h//2-190),27,COLORS['green'] if controller.completed else COLORS['danger'],True)
    score=int(controller._cave_coverage()*450+robot.minerals_found*65+robot.life_confirmed*150+robot.battery*1.4-controller.recovery.count*18)
    lines=[f"Seed: {seed}",f"Cave floor observed: {controller._cave_coverage()*100:.1f}%",f"Minerals identified: {robot.minerals_found}",f"Life sites confirmed: {robot.life_confirmed}",f"Battery remaining: {robot.battery:.1f}%",f"Algorithm switches: {len(controller.switches)}",f"Distance travelled: {robot.distance:.1f} cells",f"Recovery events: {controller.recovery.count}",f"MISSION SCORE: {score}"]
    for i,line in enumerate(lines):text(surface,line,(w//2-205,h//2-140+i*29),17)
    text(surface,"Press E to export report · S to replay · R for a new cave",(w//2-208,h//2+177),12,COLORS['muted'])
