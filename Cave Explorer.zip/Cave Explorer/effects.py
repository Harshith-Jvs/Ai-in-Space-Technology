"""Lightweight procedural particles and scan effects (no external assets)."""
import math, random
import pygame

class Effects:
    def __init__(self): self.particles=[]; self.pulses=[]
    def update(self,dt,robot):
        if random.random()<0.25:self.particles.append([robot.x+random.uniform(-1.8,1.8),robot.y+random.uniform(-1.8,1.8),random.uniform(.5,2),random.uniform(.6,2)])
        for p in self.particles:p[2]-=dt
        self.particles=[p for p in self.particles if p[2]>0]
        for p in self.pulses:p[2]+=dt
        self.pulses=[p for p in self.pulses if p[2]<2]
    def scan_pulse(self,robot):self.pulses.append([robot.x,robot.y,0.0])
    def draw(self,surface,to_screen,scale):
        for x,y,life,size in self.particles:
            sx,sy=to_screen(x,y); pygame.draw.circle(surface,(132,145,158),(sx,sy),max(1,int(size*scale*.08)))
        for x,y,t in self.pulses:
            sx,sy=to_screen(x,y); r=int((.3+t*3)*scale)
            if r>0:pygame.draw.circle(surface,(75,203,222),(sx,sy),r,1)
