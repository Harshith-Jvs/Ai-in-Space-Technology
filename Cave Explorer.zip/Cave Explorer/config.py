"""Central configuration for Cave Explorer."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Settings:
    cell_px: int = 12
    fixed_dt: float = 1.0 / 30.0
    fps_limit: int = 60
    lidar_range: int = 8
    lidar_rays: int = 64
    lidar_noise: float = 0.18
    battery_capacity: float = 100.0
    low_battery: float = 34.0
    battery_margin: float = 8.0
    scan_energy: float = 2.0
    life_scan_energy: float = 3.5
    headlight_drain: float = 0.035
    move_drain: float = 0.035
    switch_interval: float = 1.0
    stuck_seconds: float = 0.45
    localization_uncertainty_limit: float = 4.5
    frontier_min_size: int = 2
    coverage_goal: float = 0.95
    mineral_goal: int = 3
    life_goal: int = 1
    return_margin: float = 1.25
    camera_ease: float = 5.0

SETTINGS = Settings()
DIFFICULTIES = {
    "Small": (54, 38),
    "Medium": (76, 52),
    "Large": (104, 70),
}
COLORS = {
    "background": (10, 13, 19), "rock": (65, 43, 36), "rock_light": (104, 69, 53),
    "wall": (27, 27, 34), "unknown": (13, 17, 25), "free": (42, 39, 40),
    "robot": (238, 153, 82), "robot2": (94, 193, 224), "cyan": (91, 225, 230),
    "mineral_silica": (95, 192, 222), "mineral_iron": (219, 100, 69),
    "mineral_hydrated": (113, 204, 145), "life": (105, 239, 211),
    "warning": (255, 192, 87), "danger": (245, 83, 91), "text": (232, 237, 245),
    "muted": (145, 158, 177), "panel": (20, 26, 36), "green": (99, 217, 145),
}
