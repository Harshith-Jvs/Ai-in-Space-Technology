import unittest
import numpy as np
from algorithms.planning import plan_grid

class PlannerTests(unittest.TestCase):
    def test_astar_finds_valid_path(self):
        grid=np.full((12,12),-0.1,dtype=np.float32);grid[5,2:10]=0.95;grid[5,6]=-0.1
        path,expanded=plan_grid(grid,(1,1),(10,10),method='astar')
        self.assertTrue(path);self.assertEqual(path[0],(1,1));self.assertEqual(path[-1],(10,10))
        self.assertTrue(all(grid[y,x]<.72 for x,y in path))
    def test_dijkstra_reaches_goal(self):
        grid=np.full((8,8),-0.1,dtype=np.float32);path,_=plan_grid(grid,(0,0),(7,7),method='dijkstra')
        self.assertEqual(path[-1],(7,7))
if __name__=='__main__':unittest.main()
