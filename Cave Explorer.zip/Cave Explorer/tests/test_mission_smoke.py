"""Deterministic headless controller smoke test (no window is opened)."""
import importlib.util
import sys
import types
import unittest
import numpy as np

# ScoutRobot only needs pygame for draw(); simulation tests can run without SDL.
if importlib.util.find_spec("pygame") is None:
    sys.modules.setdefault("pygame", types.ModuleType("pygame"))

from cave_gen import Cave
from mapping import OccupancyMap
from robot import ScoutRobot
from controller import MissionController


class MissionSmokeTests(unittest.TestCase):
    def test_small_seed_explores_and_returns_without_battery_depletion(self):
        seed = 12345
        cave = Cave(54, 38, seed)
        belief = OccupancyMap(cave.width, cave.height)
        robot = ScoutRobot(cave.entrance)
        mission = MissionController(cave, robot, belief)
        sensor_clock = 0.0
        for frame in range(12000):
            dt = 1.0 / 30.0
            mission.update(dt)
            sensor_clock += dt
            if sensor_clock >= 0.24:
                sensor_clock -= 0.24
                belief.scan(cave, (robot.x, robot.y), 48, 13, 0.15,
                            np.random.default_rng(seed + int(mission.mission_time * 1000)))
            if mission.completed or mission.failed:
                break
        self.assertTrue(mission.completed, f"mission did not complete: {mission.phase}; {mission.events[-5:]}")
        self.assertGreater(robot.battery, 0.0)
        self.assertGreater(mission._cave_coverage(), 0.25)  # observed traversable cave-floor coverage
        self.assertLess(math_dist(robot.x, robot.y, *cave.entrance), 0.9)


def math_dist(x1, y1, x2, y2):
    return ((x1-x2)**2 + (y1-y2)**2) ** 0.5


if __name__ == "__main__":
    unittest.main()
