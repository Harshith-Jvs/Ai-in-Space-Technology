import unittest
import numpy as np
from mapping import OccupancyMap

class MappingTests(unittest.TestCase):
    def test_coverage_uses_traversable_floor_denominator(self):
        belief = OccupancyMap(4, 3)
        walkable = np.array([[0,0,0,0],[0,1,1,0],[0,1,1,0]], dtype=bool)
        belief.seen[walkable] = True
        self.assertEqual(belief.coverage(walkable), 1.0)
        self.assertLess(belief.coverage(), 1.0)

    def test_hit_endpoint_becomes_occupied(self):
        belief = OccupancyMap(8, 3)
        belief.update_ray((1,1), (5,1), True)
        self.assertLess(float(belief.probability[1,3]), 0.35)
        self.assertGreater(float(belief.probability[1,5]), 0.68)
        self.assertTrue(belief.seen[1,5])

    def test_unknown_cells_stay_unknown_until_seen(self):
        belief = OccupancyMap(5, 5)
        self.assertAlmostEqual(float(belief.probability[2,2]), 0.5, places=5)
        self.assertEqual(belief.plan_grid()[2,2], 0.5)

if __name__ == "__main__": unittest.main()
