import unittest
from collections import deque
import numpy as np
from cave_gen import Cave, WALL, PIT

class CaveTests(unittest.TestCase):
    def test_same_seed_is_deterministic(self):
        a=Cave(54,38,1234);b=Cave(54,38,1234)
        self.assertTrue((a.terrain==b.terrain).all())
        self.assertEqual(a.objects,b.objects)
    def test_walls_and_pits_are_impassable(self):
        cave=Cave(54,38,777)
        self.assertFalse(cave.is_walkable(0,0))
        pits=[(int(x),int(y)) for y,x in np.argwhere(cave.terrain==PIT)]
        for p in pits:self.assertFalse(cave.is_walkable(*p))
    def test_connectivity_across_many_seeds(self):
        for seed in range(100):
            cave = Cave(54, 38, seed)
            sx, sy = cave.entrance
            seen = {(sx, sy)}; q = deque([(sx, sy)])
            while q:
                x, y = q.popleft()
                for point in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                    if cave.is_walkable(*point) and point not in seen:
                        seen.add(point); q.append(point)
            self.assertEqual(len(seen), int(cave.walkable_mask.sum()), f"disconnected cells for seed {seed}")

    def test_cave_is_not_an_open_rectangle(self):
        cave=Cave(76,52,222)
        wall_fraction=(cave.terrain==WALL).mean()
        self.assertGreater(wall_fraction,0.35)
        self.assertLess(wall_fraction,0.9)
    def test_all_walkable_cells_connected(self):
        cave=Cave(54,38,4321); sx,sy=cave.entrance; seen={(sx,sy)};q=deque([(sx,sy)])
        while q:
            x,y=q.popleft()
            for p in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                if cave.is_walkable(*p) and p not in seen:seen.add(p);q.append(p)
        for y in range(cave.height):
            for x in range(cave.width):
                if cave.terrain[y,x] not in (WALL, PIT):self.assertIn((x,y),seen)
if __name__=='__main__':unittest.main()
