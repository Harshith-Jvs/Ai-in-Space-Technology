"""Potential-field steering and time-based stuck detection."""
from __future__ import annotations
import math

def steer(position, target, nearby_walls=(), speed=1.0):
    """Steer toward a waypoint while applying bounded wall repulsion.

    Repulsion is deliberately weaker than goal attraction so narrow corridors do not
    produce equal-and-opposite forces that cancel forward progress.
    """
    x, y = position; tx, ty = target
    dx, dy = tx-x, ty-y; mag = math.hypot(dx, dy)
    if mag < 1e-8: return (0.0, 0.0)
    vx, vy = dx/mag, dy/mag
    rx = ry = 0.0
    for wx, wy in nearby_walls:
        ax, ay = x-wx, y-wy; d = math.hypot(ax, ay)
        if 0.05 < d < 1.35:
            strength = min(0.32, (1.35-d)/1.35*0.42)
            rx += ax/d*strength; ry += ay/d*strength
    vx += rx; vy += ry
    norm = math.hypot(vx, vy)
    if norm < 1e-8: vx, vy, norm = dx/mag, dy/mag, 1.0
    return (vx/norm*speed, vy/norm*speed)

class Recovery:
    """Detect no-progress intervals; controller owns the actual escape maneuver."""
    def __init__(self, stuck_seconds=4.0):
        self.elapsed = 0.0; self.active = False; self.count = 0
        self.stuck_seconds = float(stuck_seconds)
    def update(self, moved, dt):
        if moved:
            self.elapsed = max(0.0, self.elapsed - dt*2.0)
            if self.elapsed == 0.0: self.active = False
        else:
            self.elapsed += dt
        if self.elapsed >= self.stuck_seconds and not self.active:
            self.active = True; self.count += 1
        return self.active
    def clear(self):
        self.active = False; self.elapsed = 0.0
