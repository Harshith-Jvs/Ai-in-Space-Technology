"""Grid planners: A*, Dijkstra, incremental D* Lite-style replanning, and Theta*."""
from __future__ import annotations
import heapq, math
import numpy as np

NEIGHBORS = ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1))
def _valid(grid, x, y): return 0 <= x < grid.shape[1] and 0 <= y < grid.shape[0] and grid[y,x] < 0.72

def plan_grid(grid: np.ndarray, start: tuple[int,int], goal: tuple[int,int], terrain_cost=None, method="astar"):
    """Return (path, expanded_nodes); path includes start and goal when reachable."""
    if not _valid(grid,*start) or not _valid(grid,*goal): return [], []
    h,w=grid.shape; costs=np.ones((h,w),dtype=float) if terrain_cost is None else terrain_cost
    def heuristic(p): return math.hypot(goal[0]-p[0],goal[1]-p[1]) if method in ("theta","theta*","astar") else 0.0
    gscore={start:0.0}; parent={}; heap=[(heuristic(start),0.0,start)]; expanded=[]
    while heap:
        _,g,cur=heapq.heappop(heap)
        if g > gscore.get(cur,float('inf'))+1e-9: continue
        expanded.append(cur)
        if cur==goal:
            path=[cur]
            while cur in parent: cur=parent[cur]; path.append(cur)
            path.reverse()
            if method in ("theta","theta*"): path=_shortcut(path,grid)
            return path,expanded
        for dx,dy in NEIGHBORS:
            nx,ny=cur[0]+dx,cur[1]+dy
            if not _valid(grid,nx,ny): continue
            if dx and dy and (not _valid(grid,cur[0]+dx,cur[1]) or not _valid(grid,cur[0],cur[1]+dy)): continue
            step=math.hypot(dx,dy)*float(costs[ny,nx])
            ng=g+step
            if ng+1e-9 < gscore.get((nx,ny),float('inf')):
                gscore[(nx,ny)]=ng; parent[(nx,ny)]=cur
                heapq.heappush(heap,(ng+heuristic((nx,ny)),ng,(nx,ny)))
    return [],expanded

def _line_clear(a,b,grid):
    x0,y0=a; x1,y1=b; n=max(abs(x1-x0),abs(y1-y0),1)
    for i in range(n+1):
        x=round(x0+(x1-x0)*i/n); y=round(y0+(y1-y0)*i/n)
        if not _valid(grid,x,y): return False
        if i and x != x0 and y != y0:
            if not _valid(grid, x, round(y0+(y1-y0)*(i-1)/n)) or not _valid(grid, round(x0+(x1-x0)*(i-1)/n), y):
                return False
    return True

def _shortcut(path,grid):
    if len(path)<3:return path
    result=[path[0]]; i=0
    while i<len(path)-1:
        j=len(path)-1
        while j>i+1 and not _line_clear(path[i],path[j],grid): j-=1
        result.append(path[j]); i=j
    return result

class DStarLite:
    """Practical incremental replanner facade; reuses the prior goal and replans on map changes."""
    def __init__(self): self.last_goal=None; self.last_path=[]; self.last_grid=None; self.replans=0
    def plan(self, grid, start, goal, terrain_cost=None):
        # Incremental-style facade: preserve the previous route between calls, but
        # repair it whenever occupancy, goal, or route validity changes. This is not
        # the canonical D* Lite algorithm; it provides safe adaptive replanning here.
        changed = self.last_grid is None or self.last_grid.shape != grid.shape or not np.array_equal(self.last_grid, grid)
        invalid = any(not _valid(grid, *p) for p in self.last_path)
        if goal != self.last_goal or not self.last_path or invalid or changed or start not in self.last_path:
            self.last_path, _ = plan_grid(grid, start, goal, terrain_cost, "astar")
            self.last_goal = goal; self.replans += 1
        elif start in self.last_path:
            self.last_path = self.last_path[self.last_path.index(start):]
        self.last_grid = grid.copy()
        return self.last_path, []
