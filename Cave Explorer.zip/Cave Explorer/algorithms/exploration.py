"""Frontier exploration strategies with duplicate-goal avoidance."""
from collections import deque
import math
import numpy as np

DIRECTIONS = ((1,0),(-1,0),(0,1),(0,-1))

def frontiers(belief):
    """Known-free cells adjacent to at least one unknown cell."""
    h, w = belief.shape
    out = []
    for y in range(1, h-1):
        for x in range(1, w-1):
            if belief[y, x] < 0.25 and any(0.35 <= belief[y+dy, x+dx] < 0.72 for dx,dy in DIRECTIONS):
                out.append((x, y))
    return out

def select_frontier(belief, start, strategy="utility", energy=100.0, known_cost=None, exclude=()):
    """Select a frontier target, skipping visited/nearby targets to prevent loops."""
    fs = frontiers(belief)
    if not fs: return None
    excluded = set(exclude)
    fs = [p for p in fs if p not in excluded and math.hypot(p[0]-start[0], p[1]-start[1]) > 0.35]
    if not fs: return None
    if strategy in ("nearest", "frontier"):
        return min(fs, key=lambda p: math.hypot(p[0]-start[0], p[1]-start[1]))
    best, best_score = None, -1e9
    for x, y in fs:
        unseen = sum(0.35 <= belief[y+dy, x+dx] < 0.72 for dy in (-1,0,1) for dx in (-1,0,1) if dx or dy)
        distance = math.hypot(x-start[0], y-start[1])
        terrain = 1.0 if known_cost is None else max(1.0, float(known_cost[y, x]))
        score = (unseen * 1.8 + 1.0) / (distance * terrain + 2.0)
        if energy < 35: score -= distance * 0.05
        if score > best_score: best_score, best = score, (x, y)
    return best

class WallFollower:
    def __init__(self): self.direction = 0
    def goal(self, start, belief):
        dirs = ((1,0),(0,1),(-1,0),(0,-1))
        for k in range(4):
            d = (self.direction + k) % 4; dx,dy = dirs[d]; p = (start[0]+dx, start[1]+dy)
            if 0 <= p[0] < belief.shape[1] and 0 <= p[1] < belief.shape[0] and belief[p[1],p[0]] < 0.25:
                self.direction = d; return p
        return select_frontier(belief, start, "nearest")
