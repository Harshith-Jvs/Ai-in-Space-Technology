"""Probabilistic occupancy-grid mapping and simulated LiDAR."""
from __future__ import annotations
import math
import numpy as np


class OccupancyMap:
    """Log-odds occupancy grid. Unknown cells remain unknown until observed."""
    FREE_LOG_ODDS = -1.35
    HIT_LOG_ODDS = 1.65

    def __init__(self, width: int, height: int):
        self.width, self.height = int(width), int(height)
        self.log_odds = np.zeros((self.height, self.width), dtype=np.float32)
        self.seen = np.zeros((self.height, self.width), dtype=bool)
        self.change_count = 0

    @property
    def probability(self) -> np.ndarray:
        return 1.0 / (1.0 + np.exp(-self.log_odds))

    def _inside(self, x: int, y: int) -> bool:
        return 0 <= x < self.width and 0 <= y < self.height

    def update_ray(self, start, end, hit: bool):
        """Mark intermediate cells free and (only for a hit) endpoint occupied."""
        x0, y0 = int(start[0]), int(start[1])
        x1, y1 = int(end[0]), int(end[1])
        n = max(abs(x1 - x0), abs(y1 - y0), 1)
        changed = False
        def occupancy_class(value):
            return -1 if value < -0.62 else (1 if value > 0.75 else 0)
        # Exclude the endpoint on a hit; otherwise an obstacle was incorrectly
        # updated as free and then only weakly occupied. That caused wall leaks.
        stop = n if hit else n + 1
        for i in range(stop):
            t = i / n
            x, y = int(round(x0 + (x1 - x0) * t)), int(round(y0 + (y1 - y0) * t))
            if self._inside(x, y):
                old = float(self.log_odds[y, x]); was_seen = bool(self.seen[y, x])
                self.log_odds[y, x] = max(-4.0, old - 0.75)
                self.seen[y, x] = True
                if not was_seen or occupancy_class(old) != occupancy_class(float(self.log_odds[y, x])):
                    changed = True
        if hit and self._inside(x1, y1):
            old = float(self.log_odds[y1, x1]); was_seen = bool(self.seen[y1, x1])
            self.log_odds[y1, x1] = min(4.0, old + self.HIT_LOG_ODDS)
            self.seen[y1, x1] = True
            if not was_seen or occupancy_class(old) != occupancy_class(float(self.log_odds[y1, x1])):
                changed = True
        if changed: self.change_count += 1

    def mark_free(self, x: int, y: int):
        if self._inside(int(x), int(y)):
            y, x = int(y), int(x)
            old = self.log_odds[y, x]
            self.log_odds[y, x] = min(old, self.FREE_LOG_ODDS)
            if old >= 0.0:
                self.change_count += 1
            self.seen[y, x] = True

    def mark_occupied(self, x: int, y: int):
        if self._inside(int(x), int(y)):
            y, x = int(y), int(x)
            old = self.log_odds[y, x]
            self.log_odds[y, x] = min(4.0, max(old, 0.0) + self.HIT_LOG_ODDS)
            self.seen[y, x] = True
            if old < 0.5:
                self.change_count += 1

    def plan_grid(self) -> np.ndarray:
        """Return -0.1 for free, 0.5 for unknown, 0.95 for occupied."""
        p = self.probability
        grid = np.full(p.shape, 0.5, dtype=np.float32)
        grid[p < 0.35] = -0.1
        grid[p > 0.68] = 0.95
        return grid

    def coverage(self, traversable=None) -> float:
        """Fraction of cave floor cells observed (not fraction of the whole image).

        The simulator passes the cave's traversable mask so wall pixels do not
        artificially cap the coverage score at e.g. 58% when every corridor is mapped.
        """
        if traversable is None:
            denominator = int(self.seen.size)
            return float(self.seen.sum() / denominator) if denominator else 1.0
        mask = np.asarray(traversable, dtype=bool)
        denominator = int(mask.sum())
        if denominator == 0:
            return 1.0
        return float(np.count_nonzero(self.seen & mask) / denominator)

    def raycast(self, cave, x, y, angle, max_range, noise=0.0, rng=None):
        """Cast a ray against ground-truth geometry, then update the noisy sensor map.

        Collision geometry is exact; the displayed measurement gets small range noise.
        This prevents sensor noise from making the simulated robot intentionally drive
        through a known wall while retaining imperfect measurements.
        """
        rng = rng if rng is not None else np.random.default_rng()
        start_x, start_y = int(round(x)), int(round(y))
        hit_x = hit_y = None
        hit_distance = float(max_range)
        step = 0.16
        d = step
        while d <= max_range:
            cx = int(round(x + math.cos(angle) * d))
            cy = int(round(y + math.sin(angle) * d))
            if not cave.is_walkable(cx, cy):
                hit_x, hit_y = cx, cy
                hit_distance = d
                break
            d += step
        if hit_x is not None:
            measured = max(0.3, min(max_range, hit_distance + float(rng.normal(0.0, noise))))
            # Map the actual hit cell to avoid a noisy endpoint falling on the floor.
            self.update_ray((start_x, start_y), (hit_x, hit_y), True)
            ex = int(round(x + math.cos(angle) * measured))
            ey = int(round(y + math.sin(angle) * measured))
        else:
            measured = max(0.3, min(max_range, max_range + float(rng.normal(0.0, noise))))
            ex = int(round(x + math.cos(angle) * measured))
            ey = int(round(y + math.sin(angle) * measured))
            ex = max(0, min(cave.width - 1, ex)); ey = max(0, min(cave.height - 1, ey))
            self.update_ray((start_x, start_y), (ex, ey), False)
        return (max(0, min(cave.width - 1, ex)), max(0, min(cave.height - 1, ey)))

    def scan(self, cave, position, rays=72, max_range=13, noise=0.18, rng=None):
        rng = rng if rng is not None else np.random.default_rng()
        x, y = position
        endpoints = []
        for i in range(int(rays)):
            endpoints.append(self.raycast(cave, x, y, 2.0 * math.pi * i / max(1, rays), max_range, noise, rng))
        self.mark_free(int(round(x)), int(round(y)))
        return endpoints
