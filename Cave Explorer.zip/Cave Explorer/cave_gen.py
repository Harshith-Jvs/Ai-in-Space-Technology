"""Seeded procedural Martian lava-tube network with connected winding passages.

Coordinates are grid cells. WALL and PIT are impassable; rubble and squeezes
are traversable at increased cost. Branches are carved from the main tube, so
all normal passage cells belong to the same cave network.
"""
from __future__ import annotations
import math
import numpy as np

WALL, FLOOR, RUBBLE, SQUEEZE, PIT = 0, 1, 2, 3, 4
MINERAL_TYPES = ("silica", "iron_oxide", "hydrated_mineral")


class Cave:
    def __init__(self, width: int = 76, height: int = 52, seed: int | None = None):
        self.width, self.height = max(25, int(width)), max(20, int(height))
        self.seed = int(seed if seed is not None else np.random.SeedSequence().generate_state(1)[0])
        self.rng = np.random.default_rng(self.seed)
        self.terrain = self._generate()
        self.entrance = (self.width // 2, 1)
        self.cost = np.ones((self.height, self.width), dtype=np.float32)
        self.cost[self.terrain == RUBBLE] = 2.2
        self.cost[self.terrain == SQUEEZE] = 3.0
        self.cost[self.terrain == PIT] = np.inf
        self.cost[self.terrain == WALL] = np.inf
        self.objects = self._place_objects()

    def _carve_disc(self, grid: np.ndarray, x: int, y: int, radius: int) -> None:
        """Carve a roughly circular/elliptical section of tube."""
        h, w = grid.shape
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                if dx * dx + dy * dy <= radius * radius + 0.6:
                    xx, yy = x + dx, y + dy
                    if 1 <= xx < w - 1 and 1 <= yy < h - 1:
                        grid[yy, xx] = 1

    def _walk_branch(self, grid, start, steps, initial_dir=None, radius_range=(1, 2)):
        x, y = start
        direction = initial_dir or (0, 1)
        dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        for _ in range(steps):
            # A branch mostly continues forward, with occasional bends and turns.
            if self.rng.random() < 0.30:
                choices = [d for d in dirs if d != (-direction[0], -direction[1])]
                direction = choices[int(self.rng.integers(len(choices)))]
            nx = int(np.clip(x + direction[0], 2, self.width - 3))
            ny = int(np.clip(y + direction[1], 2, self.height - 3))
            x, y = nx, ny
            radius = int(self.rng.choice(list(range(radius_range[0], radius_range[1] + 1)), p=None))
            self._carve_disc(grid, x, y, radius)
            if self.rng.random() < 0.06:
                self._carve_disc(grid, x, y, int(self.rng.integers(2, 4)))
        return (x, y)

    def _generate(self) -> np.ndarray:
        h, w = self.height, self.width
        # Start entirely solid, then carve a connected tube network. This creates
        # actual corridors, branches, dead ends, squeezes, chambers and loops.
        grid = np.zeros((h, w), dtype=np.uint8)
        x, y = w // 2, 1
        self._carve_disc(grid, x, y, 2)
        trunk_points = []
        direction = (0, 1)
        while y < h - 3:
            if self.rng.random() < 0.22:
                direction = (int(self.rng.choice([-1, 0, 1])), 1)
            x = int(np.clip(x + direction[0], 3, w - 4))
            y += 1
            self._carve_disc(grid, x, y, int(self.rng.choice([1, 1, 1, 2])))
            trunk_points.append((x, y))
            if self.rng.random() < 0.08:
                self._carve_disc(grid, x, y, int(self.rng.integers(3, 5)))

        # Connected side passages. Their turns naturally create blind ends.
        count = max(7, w // 7)
        for _ in range(count):
            if not trunk_points:
                break
            sx, sy = trunk_points[int(self.rng.integers(len(trunk_points)))]
            side = int(self.rng.choice([-1, 1]))
            start = (int(np.clip(sx + side, 2, w - 3)), sy)
            self._carve_disc(grid, *start, 1)
            self._walk_branch(grid, start, int(self.rng.integers(5, max(8, w // 2))),
                              initial_dir=(side, 0), radius_range=(1, 2))

        # Create a few cross-links between nearby passages to form loops/chambers.
        open_cells = np.argwhere(grid == 1)
        if len(open_cells):
            for _ in range(max(3, w // 18)):
                yy, xx = open_cells[int(self.rng.integers(len(open_cells)))]
                tx = int(np.clip(xx + self.rng.integers(-w // 5, w // 5 + 1), 2, w - 3))
                ty = int(np.clip(yy + self.rng.integers(-h // 7, h // 7 + 1), 2, h - 3))
                # The connecting passage is deliberately winding, not a straight open map.
                self._walk_branch(grid, (int(xx), int(yy)), int(abs(tx-xx)+abs(ty-yy)),
                                  initial_dir=(1 if tx >= xx else -1, 0), radius_range=(1, 1))
                self._carve_disc(grid, tx, ty, int(self.rng.integers(2, 5)))

        # Natural skylight throat, opening into the main tube at the north edge.
        ex = w // 2
        grid[0:4, ex-2:ex+3] = 1
        grid[0, :] = 0
        grid[0, ex-2:ex+3] = 1
        grid[-1, :] = 0
        grid[:, 0] = 0
        grid[:, -1] = 0

        terrain = np.where(grid == 1, FLOOR, WALL).astype(np.uint8)
        floors = np.argwhere(terrain == FLOOR)
        # Surface rubble and squeezes are traversable but expensive. Avoid
        # randomly blocking single-cell chokepoints.
        for yy, xx in floors:
            if yy < 4 or self.rng.random() > 0.045:
                continue
            neighbors = sum(1 for dx, dy in ((1,0),(-1,0),(0,1),(0,-1))
                            if 0 <= xx+dx < w and 0 <= yy+dy < h and terrain[yy+dy, xx+dx] != WALL)
            if neighbors >= 2:
                terrain[yy, xx] = int(self.rng.choice([RUBBLE, SQUEEZE], p=[0.67, 0.33]))

        # Pits are rare, visible, impassable hazards and only occur in wider rooms.
        for yy, xx in floors:
            if yy < 5 or self.rng.random() > 0.004:
                continue
            around = sum(1 for dy in range(-1,2) for dx in range(-1,2)
                         if (dx or dy) and 0 <= xx+dx < w and 0 <= yy+dy < h
                         and terrain[yy+dy, xx+dx] in (FLOOR, RUBBLE, SQUEEZE))
            if around >= 6:
                terrain[yy, xx] = PIT
                # A hazard must never split the cave's traversable network.
                if not self._all_walkable_connected(terrain, (w // 2, 1)):
                    terrain[yy, xx] = FLOOR
        # Reconnect any small isolated pocket created where random branches meet.
        # The connecting route is a narrow, walkable passage rather than open space.
        self._connect_components(terrain, (ex, 1))
        # Ensure the entrance and its immediate descent are clear.
        terrain[1:4, ex-2:ex+3] = FLOOR
        return terrain

    @staticmethod
    def _connect_components(terrain, start):
        from collections import deque
        h, w = terrain.shape
        def flood():
            seen = {start}; q = deque([start])
            while q:
                x, y = q.popleft()
                for nx, ny in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                    if 0 <= nx < w and 0 <= ny < h and (nx,ny) not in seen and terrain[ny,nx] not in (WALL,PIT):
                        seen.add((nx,ny)); q.append((nx,ny))
            return seen
        reachable = flood()
        candidates = [(x,y) for y in range(2,h-2) for x in range(2,w-2)
                      if terrain[y,x] in (FLOOR,RUBBLE,SQUEEZE) and (x,y) not in reachable]
        while candidates:
            x, y = candidates[0]
            tx, ty = min(reachable, key=lambda p: abs(p[0]-x)+abs(p[1]-y))
            cx, cy = x, y
            terrain[cy,cx] = FLOOR
            while cx != tx:
                cx += 1 if tx > cx else -1
                if terrain[cy,cx] == PIT: terrain[cy,cx] = FLOOR
                terrain[cy,cx] = FLOOR
            while cy != ty:
                cy += 1 if ty > cy else -1
                if terrain[cy,cx] == PIT: terrain[cy,cx] = FLOOR
                terrain[cy,cx] = FLOOR
            reachable = flood()
            candidates = [(x,y) for y in range(2,h-2) for x in range(2,w-2)
                          if terrain[y,x] in (FLOOR,RUBBLE,SQUEEZE) and (x,y) not in reachable]

    @staticmethod
    def _all_walkable_connected(terrain, start):
        from collections import deque
        h, w = terrain.shape
        if terrain[start[1], start[0]] in (WALL, PIT):
            return False
        seen = {start}; queue = deque([start])
        while queue:
            x, y = queue.popleft()
            for nx, ny in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                if 0 <= nx < w and 0 <= ny < h and (nx,ny) not in seen and terrain[ny,nx] not in (WALL,PIT):
                    seen.add((nx,ny)); queue.append((nx,ny))
        for y in range(h):
            for x in range(w):
                if terrain[y,x] not in (WALL,PIT) and (x,y) not in seen:
                    return False
        return True

    def _place_objects(self):
        rng = self.rng
        objs = []
        candidates = np.argwhere(np.isin(self.terrain, [FLOOR, RUBBLE, SQUEEZE]))
        if len(candidates) == 0:
            return objs
        chosen = {self.entrance}
        # Spread targets apart so one scan does not reveal a cluster all at once.
        specs = [("mineral", max(8, self.width // 5)), ("life", max(2, self.width // 32)),
                 ("false_positive", max(2, self.width // 27)), ("ice", max(3, self.width // 20)),
                 ("radiation", max(2, self.width // 28))]
        for kind, amount in specs:
            attempts = 0
            added = 0
            while added < amount and attempts < amount * 30:
                attempts += 1
                yy, xx = candidates[int(rng.integers(len(candidates)))]
                pos = (int(xx), int(yy))
                if pos in chosen:
                    continue
                if any(abs(pos[0]-p[0]) + abs(pos[1]-p[1]) < 3 for p in chosen):
                    continue
                chosen.add(pos)
                subtype = str(rng.choice(MINERAL_TYPES)) if kind == "mineral" else kind
                objs.append({"x":pos[0], "y":pos[1], "kind":kind, "type":subtype,
                             "found":False, "confirmed":False, "confidence":0.0})
                added += 1
        return objs

    @property
    def walkable_mask(self) -> np.ndarray:
        """Ground-truth mask of traversable cave floor cells (for simulation metrics)."""
        return ~np.isin(self.terrain, (WALL, PIT))

    def is_walkable(self, x: int, y: int) -> bool:
        return (0 <= x < self.width and 0 <= y < self.height
                and self.terrain[y, x] not in (WALL, PIT))

    def can_occupy(self, x: float, y: float, radius: float = 0.22) -> bool:
        """Check the robot's footprint, not just its centre cell."""
        for ox, oy in ((0,0), (radius,0), (-radius,0), (0,radius), (0,-radius),
                       (radius*.7,radius*.7), (radius*.7,-radius*.7),
                       (-radius*.7,radius*.7), (-radius*.7,-radius*.7)):
            cx, cy = int(math.floor(x + ox + 0.5)), int(math.floor(y + oy + 0.5))
            if not self.is_walkable(cx, cy):
                return False
        return True
